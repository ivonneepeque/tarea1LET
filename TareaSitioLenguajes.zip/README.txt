Lenguajes, Estándares y Tecnologías para la Web 

Trabajo: Elaboración de un sitio web en HTML5 y hojas de estilo CSS3

- Se realizó sitio con temática de Top 4 Destinos en México
- Se utilizó la librería Bootstrap como soporte para los estilos del sitio
- Para el formulario, se creo una página "Contacto", en este caso 
  al no estar involucradas funciones del lado del servidor se utilizó 
  "mailto" para el envío del formulario, envío a mi correo (eimi65.carter@gmail.com).

Estructura:

Carpeta css -> contiene hojas de estilos, se utilizó bootstrap pero a su vez se creó una hoja propia para detalles particulares “style.css”
Carpeta js -> scripts necesarios
Carpeta recursos -> contiene imágenes, audios y videos incluidos en el sitio



